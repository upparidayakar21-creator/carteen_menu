import csv
import json
import os
import itertools
from datetime import datetime
from collections import defaultdict

APP_NAME = "CANTEEN MENU ANALYZER"
JSON_FILE = "menu_data.json"
CSV_FILE = "menu_data.csv"
REPORT_FILE = "menu_report.md"
LOG_FILE = "audit_log.txt"

SAMPLE_MENU = [
    {"id": 1, "name": "Idli", "category": "Breakfast", "price": 30},
    {"id": 2, "name": "Dosa", "category": "Breakfast", "price": 40},
    {"id": 3, "name": "Masala Dosa", "category": "Breakfast", "price": 60},
    {"id": 4, "name": "Poori", "category": "Breakfast", "price": 45},
    {"id": 5, "name": "Upma", "category": "Breakfast", "price": 25},
    {"id": 6, "name": "Pongal", "category": "Breakfast", "price": 35},
    {"id": 7, "name": "Chapati", "category": "Lunch", "price": 40},
    {"id": 8, "name": "Veg Meals", "category": "Lunch", "price": 90},
    {"id": 9, "name": "Chicken Meals", "category": "Lunch", "price": 130},
    {"id": 10, "name": "Veg Biryani", "category": "Lunch", "price": 100},
    {"id": 11, "name": "Chicken Biryani", "category": "Lunch", "price": 150},
    {"id": 12, "name": "Curd Rice", "category": "Lunch", "price": 45},
    {"id": 13, "name": "Fried Rice", "category": "Lunch", "price": 80},
    {"id": 14, "name": "Paneer Rice", "category": "Lunch", "price": 110},
    {"id": 15, "name": "Veg Noodles", "category": "Snacks", "price": 70},
    {"id": 16, "name": "Samosa", "category": "Snacks", "price": 15},
    {"id": 17, "name": "Puff", "category": "Snacks", "price": 20},
    {"id": 18, "name": "Sandwich", "category": "Snacks", "price": 50},
    {"id": 19, "name": "Burger", "category": "Snacks", "price": 65},
    {"id": 20, "name": "Pizza", "category": "Snacks", "price": 120},
    {"id": 21, "name": "French Fries", "category": "Snacks", "price": 60},
    {"id": 22, "name": "Tea", "category": "Drinks", "price": 10},
    {"id": 23, "name": "Coffee", "category": "Drinks", "price": 15},
    {"id": 24, "name": "Fresh Juice", "category": "Drinks", "price": 40},
    {"id": 25, "name": "Lemon Juice", "category": "Drinks", "price": 25},
    {"id": 26, "name": "Milkshake", "category": "Drinks", "price": 60},
    {"id": 27, "name": "Water Bottle", "category": "Drinks", "price": 20},
    {"id": 28, "name": "Ice Cream", "category": "Dessert", "price": 40},
    {"id": 29, "name": "Gulab Jamun", "category": "Dessert", "price": 30},
    {"id": 30, "name": "Cake", "category": "Dessert", "price": 50},
    {"id": 31, "name": "Veg Roll", "category": "Snacks", "price": 45},
    {"id": 32, "name": "Egg Rice", "category": "Lunch", "price": 90},
    {"id": 33, "name": "Paratha", "category": "Breakfast", "price": 50},
    {"id": 34, "name": "Fruit Salad", "category": "Dessert", "price": 55},
    {"id": 35, "name": "Buttermilk", "category": "Drinks", "price": 15}
]

def load_data():
    if not os.path.exists(JSON_FILE):
        save_data(SAMPLE_MENU)
        return SAMPLE_MENU.copy()
    try:
        with open(JSON_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("Invalid data format")
        return data
    except (json.JSONDecodeError, ValueError, OSError):
        print("\nWARNING: Data file is damaged. Loading sample menu instead.")
        return SAMPLE_MENU.copy()

def save_data(menu):
    with open(JSON_FILE, "w", encoding="utf-8") as file:
        json.dump(menu, file, indent=4)
    export_csv(menu)

def export_csv(menu):
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["id", "name", "category", "price"])
        writer.writeheader()
        writer.writerows(menu)

def log_activity(message):
    with open(LOG_FILE, "a", encoding="utf-8") as file:
        file.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}\n")

def get_integer(message, minimum=1):
    while True:
        try:
            value = int(input(message))
            if value < minimum:
                print(f"Enter a value greater than or equal to {minimum}.")
                continue
            return value
        except ValueError:
            print("Invalid input! Enter a valid number.")

def get_price(message):
    while True:
        try:
            value = float(input(message))
            if not 0 < value <= 100000:
                print("Price must be between 0 and 100000.")
                continue
            return round(value, 2)
        except ValueError:
            print("Please enter a valid price.")

def get_text(message):
    while True:
        value = input(message).strip()
        if value and len(value) <= 60:
            return value
        print("Input cannot be empty or longer than 60 characters.")

def display_menu(menu):
    if not menu:
        print("\nNo menu items available.")
        return
    print("\n" + "=" * 75)
    print(f"{'ID':<8}{'ITEM NAME':<25}{'CATEGORY':<20}{'PRICE':>12}")
    print("=" * 75)
    for item in menu:
        print(f"{item['id']:<8}{item['name']:<25}{item['category']:<20}Rs. {item['price']:>8.2f}")
    print("=" * 75)

def add_item(menu):
    print("\n--- ADD NEW MENU ITEM ---")
    item_id = max((item["id"] for item in menu), default=0) + 1
    name = get_text("Enter item name: ")
    category = get_text("Enter category (Breakfast/Lunch/Snacks/Drinks/Dessert): ")
    price = get_price("Enter price (Rs.): ")
    menu.append({"id": item_id, "name": name, "category": category.title(), "price": price})
    save_data(menu)
    log_activity(f"Added item: {name}")
    print("\nItem added successfully!")

def update_item(menu):
    display_menu(menu)
    item_id = get_integer("\nEnter item ID to update: ")
    item = next((x for x in menu if x["id"] == item_id), None)
    if item is None:
        print("Item not found!")
        return
    print("1. Update Name\n2. Update Category\n3. Update Price")
    choice = get_integer("Choose option: ")
    if choice == 1:
        item["name"] = get_text("Enter new name: ")
    elif choice == 2:
        item["category"] = get_text("Enter new category: ").title()
    elif choice == 3:
        item["price"] = get_price("Enter new price: ")
    else:
        print("Invalid choice!")
        return
    save_data(menu)
    log_activity(f"Updated item ID: {item_id}")
    print("Item updated successfully!")

def delete_item(menu):
    display_menu(menu)
    item_id = get_integer("\nEnter item ID to delete: ")
    item = next((x for x in menu if x["id"] == item_id), None)
    if item is None:
        print("Item not found!")
        return
    confirm = input(f"Delete {item['name']}? (yes/no): ").strip().lower()
    if confirm == "yes":
        menu.remove(item)
        save_data(menu)
        log_activity(f"Deleted item: {item['name']}")
        print("Item deleted successfully!")
    else:
        print("Deletion cancelled.")

def search_menu(menu):
    keyword = input("\nEnter item name or category: ").strip().lower()
    results = [item for item in menu if keyword in item["name"].lower() or keyword in item["category"].lower()]
    if results:
        print("\nSearch Results:")
        display_menu(results)
    else:
        print("No matching items found.")

def filter_category(menu):
    category = get_text("Enter category: ").lower()
    results = [item for item in menu if item["category"].lower() == category]
    display_menu(results)

def affordable_meals(menu):
    print("\n--- AFFORDABLE MEAL FINDER ---")
    budget = get_price("Enter your budget (Rs.): ")
    max_items = min(get_integer("Maximum number of items in a combination (1-5): "), 5)
    affordable = []
    for size in range(1, max_items + 1):
        for combination in itertools.combinations(menu, size):
            total = sum(item["price"] for item in combination)
            if total <= budget:
                affordable.append((combination, total))
    affordable.sort(key=lambda x: (-len(x[0]), x[1]))
    if not affordable:
        print("No affordable combinations found.")
        return
    print(f"\nAffordable combinations within Rs. {budget:.2f}")
    print("-" * 65)
    for index, (combination, total) in enumerate(affordable[:20], 1):
        names = " + ".join(item["name"] for item in combination)
        print(f"{index}. {names} = Rs. {total:.2f}")
    print("-" * 65)
    print(f"Total combinations found: {len(affordable)}")

def price_analysis(menu):
    if not menu:
        print("No data available.")
        return
    prices = [item["price"] for item in menu]
    print("\n--- PRICE ANALYSIS ---")
    print(f"Total Menu Items : {len(menu)}")
    print(f"Total Price      : Rs. {sum(prices):.2f}")
    print(f"Average Price    : Rs. {sum(prices)/len(prices):.2f}")
    print(f"Minimum Price    : Rs. {min(prices):.2f}")
    print(f"Maximum Price    : Rs. {max(prices):.2f}")
    print(f"Cheapest Item    : {min(menu, key=lambda x: x['price'])['name']}")
    print(f"Costliest Item   : {max(menu, key=lambda x: x['price'])['name']}")
    print("\n--- CATEGORY ANALYSIS ---")
    categories = defaultdict(list)
    for item in menu:
        categories[item["category"]].append(item["price"])
    for category, values in categories.items():
        print(f"{category:<15} Items: {len(values):<5} Average: Rs. {sum(values)/len(values):.2f}")

def budget_warnings(menu):
    print("\n--- PRICE WARNING SYSTEM ---")
    limit = get_price("Enter maximum acceptable price: ")
    found = False
    for item in menu:
        if item["price"] > limit:
            found = True
            print(f"WARNING: {item['name']} costs Rs. {item['price']:.2f}")
    if not found:
        print("All menu items are within your price limit.")

def sort_menu(menu):
    print("\n1. Sort by Price (Low to High)\n2. Sort by Price (High to Low)\n3. Sort by Name")
    choice = get_integer("Choose option: ")
    if choice == 1:
        results = sorted(menu, key=lambda x: x["price"])
    elif choice == 2:
        results = sorted(menu, key=lambda x: x["price"], reverse=True)
    elif choice == 3:
        results = sorted(menu, key=lambda x: x["name"].lower())
    else:
        print("Invalid option!")
        return
    display_menu(results)

def bulk_import(menu):
    filename = input("Enter CSV filename: ").strip()
    if not os.path.isfile(filename):
        print("CSV file not found!")
        return
    added, errors = 0, []
    try:
        with open(filename, "r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            required = {"name", "category", "price"}
            if not required.issubset(set(reader.fieldnames or [])):
                print("CSV must contain name, category and price columns.")
                return
            for row_number, row in enumerate(reader, start=2):
                try:
                    name, category = row["name"].strip(), row["category"].strip()
                    price = float(row["price"])
                    if not name or not category:
                        raise ValueError("Missing name or category")
                    if not 0 < price <= 100000:
                        raise ValueError("Price outside allowed range")
                    item_id = max((x["id"] for x in menu), default=0) + 1
                    menu.append({"id": item_id, "name": name, "category": category.title(), "price": round(price, 2)})
                    added += 1
                except (ValueError, TypeError, KeyError) as error:
                    errors.append(f"Row {row_number}: {error}")
        save_data(menu)
        print(f"\nSuccessfully imported: {added} items")
        if errors:
            print("\nImport errors:")
            for error in errors:
                print(error)
        log_activity(f"Bulk imported {added} items")
    except OSError as error:
        print("Unable to read CSV file:", error)

def generate_report(menu):
    if not menu:
        print("No data available for report.")
        return
    prices = [item["price"] for item in menu]
    with open(REPORT_FILE, "w", encoding="utf-8") as file:
        file.write("# CANTEEN MENU ANALYZER REPORT\n\n")
        file.write(f"Generated: {datetime.now().strftime('%d-%m-%Y %H:%M')}\n\n")
        file.write("## Executive Summary\n\n")
        file.write(f"- Total items: {len(menu)}\n- Total price: Rs. {sum(prices):.2f}\n")
        file.write(f"- Average price: Rs. {sum(prices)/len(prices):.2f}\n")
        file.write(f"- Minimum price: Rs. {min(prices):.2f}\n- Maximum price: Rs. {max(prices):.2f}\n\n")
        file.write("## Menu Details\n\n| ID | Name | Category | Price |\n|---|---|---|---:|\n")
        for item in menu:
            file.write(f"| {item['id']} | {item['name']} | {item['category']} | Rs. {item['price']:.2f} |\n")
        file.write("\n## Category Summary\n\n")
        categories = defaultdict(list)
        for item in menu:
            categories[item["category"]].append(item["price"])
        for category, values in categories.items():
            file.write(f"- {category}: {len(values)} items, average Rs. {sum(values)/len(values):.2f}\n")
    print(f"\nReport generated: {REPORT_FILE}")
    log_activity("Generated executive report")

def dashboard():
    print("\n" + "=" * 65)
    print("             CANTEEN MENU ANALYZER")
    print("                  GreenFuture Hack")
    print("=" * 65)
    print("  Manage Menu | Analyze Prices | Find Affordable Meals")
    print("=" * 65)

def main():
    menu = load_data()
    while True:
        dashboard()
        print("""
        1.  Display All Menu Items
        2.  Add New Menu Item
        3.  Update Menu Item
        4.  Delete Menu Item
        5.  Search Menu Items
        6.  Filter by Category
        7.  Affordable Meal Combinations
        8.  Price Analysis & Executive Summary
        9.  Budget Warning System
        10. Sort Menu Items
        11. Bulk CSV Import
        12. Export Executive Report
        13. Export CSV File
        14. View Activity Log
        15. Refresh Data
        0.  Exit Application
        """)
        choice = input("Enter your choice: ").strip()
        if choice == "1":
            display_menu(menu)
        elif choice == "2":
            add_item(menu)
        elif choice == "3":
            update_item(menu)
        elif choice == "4":
            delete_item(menu)
        elif choice == "5":
            search_menu(menu)
        elif choice == "6":
            filter_category(menu)
        elif choice == "7":
            affordable_meals(menu)
        elif choice == "8":
            price_analysis(menu)
        elif choice == "9":
            budget_warnings(menu)
        elif choice == "10":
            sort_menu(menu)
        elif choice == "11":
            bulk_import(menu)
        elif choice == "12":
            generate_report(menu)
        elif choice == "13":
            export_csv(menu)
            print("CSV exported successfully!")
        elif choice == "14":
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, "r", encoding="utf-8") as file:
                    print("\n--- ACTIVITY LOG ---")
                    print(file.read())
            else:
                print("No activity recorded yet.")
        elif choice == "15":
            menu = load_data()
            print("Data refreshed successfully!")
        elif choice == "0":
            save_data(menu)
            log_activity("Application closed")
            print("\nThank you for using Canteen Menu Analyzer!")
            print("Your data has been saved successfully.")
            break
        else:
            print("Invalid choice! Please select a valid option.")
        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()

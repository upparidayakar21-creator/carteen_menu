CANTEEN MENU ANALYZER
=====================

Requirements:
- Python 3.10 or newer
- No third-party packages required

How to run:
1. Extract this ZIP file.
2. Open a terminal in the extracted folder.
3. Run: python canteen_menu_analyzer.py

The application automatically creates:
- menu_data.json (persistent menu data)
- menu_data.csv (CSV copy of menu data)
- menu_report.md (generated when you export a report)
- audit_log.txt (activity history)

Features:
- Add, update and delete menu items
- Search and category filtering
- Affordable meal combinations
- Price and category analysis
- Budget warnings and sorting
- Bulk CSV import with row-level error messages
- CSV export and Markdown report generation
- JSON/CSV persistence and activity logging

Bulk CSV import format:
name,category,price
Idli,Breakfast,30
Veg Meals,Lunch,90

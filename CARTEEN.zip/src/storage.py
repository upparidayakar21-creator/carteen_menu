"""
Persistence & Bulk Ingestion Repository for Canteen Menu Analyzer.
Handles atomic CSV/JSON read-write operations, PermissionError / OSError recovery,
and row-by-row validated bulk CSV imports.
"""

import csv
import json
import os
import tempfile
from typing import List, Tuple, Dict, Any

from src.models import MenuItem
from src.validators import (
    ValidationError,
    validate_item_id,
    sanitize_text,
    validate_category,
    validate_price,
    validate_calories,
    validate_bool_flag,
)

CSV_COLUMNS = ["item_id", "name", "category", "price", "calories", "is_veg", "available", "updated_at"]


class StorageError(RuntimeError):
    """Raised when OS-level file locks, permissions, or disk errors block persistence."""


class MenuRepository:
    """Repository pattern decoupling file I/O from analytics and UI presentation."""

    def __init__(self, csv_path: str = "data/menu_items.csv", json_path: str = "data/menu_items.json"):
        self.csv_path = csv_path
        self.json_path = json_path
        os.makedirs(os.path.dirname(self.csv_path) or ".", exist_ok=True)
        os.makedirs(os.path.dirname(self.json_path) or ".", exist_ok=True)

    def load_all(self) -> List[MenuItem]:
        """Loads menu items from JSON (primary) or CSV (fallback), recovering gracefully on corruption."""
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as fh:
                    payload = json.load(fh)
                if isinstance(payload, list):
                    return [self._parse_item_dict(entry) for entry in payload]
            except (json.JSONDecodeError, KeyError, ValueError):
                # Fall back to CSV if JSON is corrupted
                pass
            except (PermissionError, OSError) as exc:
                raise StorageError(f"OS file lock or permission error reading {self.json_path}: {exc}") from exc

        if os.path.exists(self.csv_path):
            return self._load_from_csv(self.csv_path)[0]

        return []

    def save_all(self, items: List[MenuItem]) -> None:
        """Atomically persists menu catalog to both JSON and CSV using temp files + os.replace."""
        self._atomic_write_json(items)
        self._atomic_write_csv(items)

    def _atomic_write_json(self, items: List[MenuItem]) -> None:
        target_dir = os.path.dirname(self.json_path) or "."
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile("w", dir=target_dir, delete=False, encoding="utf-8", suffix=".tmp") as tmp:
                tmp_path = tmp.name
                json.dump([item.to_dict() for item in items], tmp, indent=2)
            os.replace(tmp_path, self.json_path)
        except (PermissionError, OSError) as exc:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            raise StorageError(f"Unable to write JSON store (file locked or read-only): {exc}") from exc

    def _atomic_write_csv(self, items: List[MenuItem]) -> None:
        target_dir = os.path.dirname(self.csv_path) or "."
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile("w", dir=target_dir, delete=False, encoding="utf-8", newline="", suffix=".tmp") as tmp:
                tmp_path = tmp.name
                writer = csv.DictWriter(tmp, fieldnames=CSV_COLUMNS)
                writer.writeheader()
                for item in items:
                    writer.writerow(item.to_dict())
            os.replace(tmp_path, self.csv_path)
        except (PermissionError, OSError) as exc:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            raise StorageError(f"Unable to write CSV store (file locked or read-only): {exc}") from exc

    def _parse_item_dict(self, row: Dict[str, Any]) -> MenuItem:
        item_id = validate_item_id(row.get("item_id", ""))
        name = sanitize_text(str(row.get("name", "")), field_name="Item Name")
        category = validate_category(row.get("category", ""))
        price = validate_price(row.get("price", ""))
        calories = validate_calories(row.get("calories", ""))
        is_veg = validate_bool_flag(row.get("is_veg", True))
        available = validate_bool_flag(row.get("available", True))
        updated_at = str(row.get("updated_at") or "").strip()
        item = MenuItem(
            item_id=item_id,
            name=name,
            category=category,
            price=price,
            calories=calories,
            is_veg=is_veg,
            available=available,
        )
        if updated_at:
            item.updated_at = updated_at
        return item

    def _load_from_csv(self, file_path: str) -> Tuple[List[MenuItem], List[str]]:
        valid_items: List[MenuItem] = []
        error_logs: List[str] = []
        try:
            with open(file_path, "r", encoding="utf-8", newline="") as fh:
                reader = csv.DictReader(fh)
                for line_no, row in enumerate(reader, start=2):
                    try:
                        valid_items.append(self._parse_item_dict(row))
                    except (ValidationError, KeyError, ValueError) as exc:
                        error_logs.append(f"Row {line_no}: {exc}")
        except FileNotFoundError as exc:
            raise StorageError(f"CSV file not found: {file_path}") from exc
        except (PermissionError, OSError) as exc:
            raise StorageError(f"OS file permission error reading {file_path}: {exc}") from exc
        return valid_items, error_logs

    def bulk_import_csv(self, import_path: str, existing_items: List[MenuItem]) -> Tuple[List[MenuItem], int, List[str]]:
        """Ingests external CSV menu datasets with row-by-row validation and duplicate ID protection."""
        imported, error_logs = self._load_from_csv(import_path)
        by_id = {item.item_id: item for item in existing_items}
        added_count = 0
        for item in imported:
            if item.item_id in by_id:
                error_logs.append(f"Duplicate ID {item.item_id} ({item.name}) skipped.")
                continue
            by_id[item.item_id] = item
            added_count += 1
        return list(by_id.values()), added_count, error_logs

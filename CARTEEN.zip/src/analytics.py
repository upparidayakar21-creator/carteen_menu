"""
Core Business Logic & Analytics Engine for Canteen Menu Analyzer.
Strictly decoupled from terminal I/O so every computation is deterministic and unit-testable.
"""

import csv
import itertools
import math
import statistics
from datetime import datetime
from typing import List, Dict, Any, Tuple, Optional

from src.models import MenuItem, MealCombo, PREMIUM_PRICE_WARNING_INR


def paginate_items(items: List[MenuItem], page: int = 1, page_size: int = 10) -> Tuple[List[MenuItem], int, int]:
    """Slices a menu list into fixed-size pages for scalable terminal viewing."""
    if page_size <= 0:
        page_size = 10
    total_pages = max(1, math.ceil(len(items) / page_size))
    safe_page = min(max(1, page), total_pages)
    start = (safe_page - 1) * page_size
    return items[start : start + page_size], safe_page, total_pages


def filter_items(
    items: List[MenuItem],
    keyword: str = "",
    category: str = "",
    veg_only: bool = False,
    available_only: bool = False,
    max_price: Optional[float] = None,
) -> List[MenuItem]:
    """Filters menu records by keyword, category, dietary tag, availability, and price cap."""
    kw = keyword.strip().lower()
    cat = category.strip().lower()
    results: List[MenuItem] = []

    for item in items:
        if kw and kw not in item.name.lower() and kw not in item.item_id.lower() and kw not in item.category.lower():
            continue
        if cat and item.category.lower() != cat:
            continue
        if veg_only and not item.is_veg:
            continue
        if available_only and not item.available:
            continue
        if max_price is not None and item.price > max_price:
            continue
        results.append(item)

    return sorted(results, key=lambda x: (x.category, x.price, x.name))


def compute_menu_summary(items: List[MenuItem]) -> Dict[str, Any]:
    """Computes executive price & nutritional metrics across all menu items and categories."""
    if not items:
        return {
            "total_items": 0,
            "available_items": 0,
            "unavailable_items": 0,
            "veg_count": 0,
            "non_veg_count": 0,
            "avg_price": 0.0,
            "median_price": 0.0,
            "min_item": None,
            "max_item": None,
            "avg_calories": 0.0,
            "category_breakdown": {},
            "warnings": [],
        }

    prices = [i.price for i in items]
    calories = [i.calories for i in items]
    min_item = min(items, key=lambda x: x.price)
    max_item = max(items, key=lambda x: x.price)

    cat_groups: Dict[str, List[MenuItem]] = {}
    for item in items:
        cat_groups.setdefault(item.category, []).append(item)

    category_breakdown: Dict[str, Dict[str, Any]] = {}
    for cat, group in sorted(cat_groups.items()):
        cat_prices = [g.price for g in group]
        category_breakdown[cat] = {
            "count": len(group),
            "avg_price": round(statistics.mean(cat_prices), 2),
            "min_price": round(min(cat_prices), 2),
            "max_price": round(max(cat_prices), 2),
        }

    warnings: List[str] = []
    unavailable = [i for i in items if not i.available]
    if unavailable:
        warnings.append(f"{len(unavailable)} menu item(s) currently marked OUT OF STOCK.")
    anomalous = [i for i in items if i.price > PREMIUM_PRICE_WARNING_INR]
    if anomalous:
        names = ", ".join(f"{i.name} (Rs.{i.price:.0f})" for i in anomalous[:4])
        warnings.append(f"High-price threshold alert (> Rs.{PREMIUM_PRICE_WARNING_INR:.0f}): {names}")

    return {
        "total_items": len(items),
        "available_items": sum(1 for i in items if i.available),
        "unavailable_items": len(unavailable),
        "veg_count": sum(1 for i in items if i.is_veg),
        "non_veg_count": sum(1 for i in items if not i.is_veg),
        "avg_price": round(statistics.mean(prices), 2),
        "median_price": round(statistics.median(prices), 2),
        "min_item": min_item,
        "max_item": max_item,
        "avg_calories": round(statistics.mean(calories), 1),
        "category_breakdown": category_breakdown,
        "warnings": warnings,
    }


def find_affordable_combos(
    items: List[MenuItem],
    max_budget: float,
    combo_size: int = 2,
    veg_only: bool = False,
    distinct_categories: bool = True,
    top_n: int = 10,
) -> List[MealCombo]:
    """
    Finds optimal multi-item meal combinations within budget using itertools.combinations
    and ranks them by nutritional value-per-rupee and budget utilization.
    """
    if max_budget <= 0 or combo_size < 2 or combo_size > 4:
        return []

    eligible = [
        i for i in items
        if i.available and i.price <= max_budget and (not veg_only or i.is_veg)
    ]
    # Keep cheapest 28 eligible items to guarantee sub-millisecond performance even on large menus
    eligible.sort(key=lambda x: x.price)
    candidates = eligible[:28]

    combos: List[MealCombo] = []
    for group in itertools.combinations(candidates, combo_size):
        total_price = round(sum(i.price for i in group), 2)
        if total_price > max_budget:
            continue
        if distinct_categories and len({i.category for i in group}) < combo_size:
            continue

        total_calories = sum(i.calories for i in group)
        budget_remaining = round(max_budget - total_price, 2)
        # Value score balances calorie fullness per rupee + high budget efficiency
        cal_per_rupee = total_calories / max(total_price, 1.0)
        utilization = total_price / max_budget
        value_score = round((cal_per_rupee * 0.65) + (utilization * 100 * 0.35), 2)

        combos.append(
            MealCombo(
                items=group,
                total_price=total_price,
                total_calories=total_calories,
                budget_remaining=budget_remaining,
                value_score=value_score,
            )
        )

    combos.sort(key=lambda c: (-c.value_score, c.total_price))
    return combos[:top_n]


def export_reports(items: List[MenuItem], reports_dir: str = "reports") -> Dict[str, str]:
    """Exports Executive Summary in Markdown, Plain-Text Audit Log, Standardized CSV, and Chart (if Matplotlib is available)."""
    import os

    os.makedirs(reports_dir, exist_ok=True)
    summary = compute_menu_summary(items)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    md_path = os.path.join(reports_dir, "canteen_executive_summary.md")
    txt_path = os.path.join(reports_dir, "canteen_audit_log.txt")
    csv_path = os.path.join(reports_dir, "category_price_summary.csv")

    # 1. Markdown Executive Report
    with open(md_path, "w", encoding="utf-8") as mf:
        mf.write("# Canteen Menu Analyzer — Executive Summary Report\n\n")
        mf.write(f"- **Generated At:** {timestamp}\n")
        mf.write(f"- **Total Menu Items:** {summary['total_items']} ({summary['available_items']} Available, {summary['unavailable_items']} Out of Stock)\n")
        mf.write(f"- **Dietary Split:** {summary['veg_count']} Veg | {summary['non_veg_count']} Non-Veg\n")
        mf.write(f"- **Average Item Price:** Rs.{summary['avg_price']:.2f} (Median: Rs.{summary['median_price']:.2f})\n")
        mf.write(f"- **Average Calories:** {summary['avg_calories']:.1f} kcal\n\n")

        mf.write("## Category-Wise Pricing Breakdown\n\n")
        mf.write("| Category | Items | Avg Price (Rs.) | Min Price (Rs.) | Max Price (Rs.) |\n")
        mf.write("| :--- | :---: | :---: | :---: | :---: |\n")
        for cat, stats in summary["category_breakdown"].items():
            mf.write(
                f"| {cat} | {stats['count']} | {stats['avg_price']:.2f} | {stats['min_price']:.2f} | {stats['max_price']:.2f} |\n"
            )

        combos = find_affordable_combos(items, max_budget=100.0, combo_size=2, top_n=5)
        mf.write("\n## Top 5 Affordable Student Meal Combos (Under Rs.100)\n\n")
        for idx, combo in enumerate(combos, start=1):
            mf.write(
                f"{idx}. **{combo.label}** — Rs.{combo.total_price:.2f} ({combo.total_calories} kcal, Rs.{combo.budget_remaining:.2f} saved)\n"
            )

    # 2. Plain-Text Audit Log
    with open(txt_path, "w", encoding="utf-8") as tf:
        tf.write(f"CANTEEN MENU ANALYZER AUDIT LOG [{timestamp}]\n")
        tf.write("=" * 60 + "\n")
        tf.write(f"Total Items: {summary['total_items']} | Avg Price: Rs.{summary['avg_price']:.2f}\n")
        for w in summary["warnings"]:
            tf.write(f"[WARNING] {w}\n")
        tf.write("-" * 60 + "\n")
        for item in items:
            tf.write(
                f"{item.item_id:<8} | {item.name:<26} | {item.category:<13} | Rs.{item.price:>6.2f} | {item.calories:>4} kcal\n"
            )

    # 3. Standardized Category CSV
    with open(csv_path, "w", encoding="utf-8", newline="") as cf:
        writer = csv.writer(cf)
        writer.writerow(["Category", "Item_Count", "Avg_Price_INR", "Min_Price_INR", "Max_Price_INR"])
        for cat, stats in summary["category_breakdown"].items():
            writer.writerow([cat, stats["count"], stats["avg_price"], stats["min_price"], stats["max_price"]])

    exported = {"markdown": md_path, "audit_log": txt_path, "csv": csv_path}

    # 4. Optional Matplotlib Category Price Chart (graceful fallback if not installed)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        if summary["category_breakdown"]:
            cats = list(summary["category_breakdown"].keys())
            avgs = [summary["category_breakdown"][c]["avg_price"] for c in cats]
            chart_path = os.path.join(reports_dir, "category_prices_chart.png")

            plt.figure(figsize=(9, 5))
            bars = plt.bar(cats, avgs, color="#0f766e")
            for bar in bars:
                h = bar.get_height()
                plt.text(bar.get_x() + bar.get_width() / 2, h + 1.5, f"Rs.{h:.1f}", ha="center", va="bottom", fontsize=9)
            plt.title("Average Canteen Menu Price by Category (INR)")
            plt.ylabel("Average Price (Rs.)")
            plt.ylim(0, max(avgs) * 1.2 + 10)
            plt.grid(axis="y", linestyle="--", alpha=0.5)
            plt.tight_layout()
            plt.savefig(chart_path)
            plt.close()
            exported["chart"] = chart_path
    except ImportError:
        pass

    return exported

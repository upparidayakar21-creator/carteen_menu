"""Canteen Menu Analyzer — Modular 3-Layer Python Application."""

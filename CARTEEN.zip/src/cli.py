"""
Terminal User Interface (TUI) Layer for Canteen Menu Analyzer.
Handles ANSI presentation, fixed-width paginated tables, and menu dispatch.
"""

from typing import List
from src.models import MenuItem, VALID_CATEGORIES
from src.validators import (
    ValidationError,
    prompt_validated,
    validate_item_id,
    sanitize_text,
    validate_category,
    validate_price,
    validate_calories,
    validate_bool_flag,
)
from src.storage import MenuRepository, StorageError
from src.analytics import (
    paginate_items,
    filter_items,
    compute_menu_summary,
    find_affordable_combos,
    export_reports,
)

GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def print_banner() -> None:
    print(f"\n{CYAN}{BOLD}{'=' * 74}")
    print("CANTEEN MENU ANALYZER — BUDGET COMBO & PRICING INTELLIGENCE".center(74))
    print(f"{'=' * 74}{RESET}")


def render_items_table(items: List[MenuItem], page_size: int = 10) -> None:
    """Renders paginated fixed-width terminal tables so large menus stay clean and readable."""
    if not items:
        print(f"{YELLOW}No matching menu items found.{RESET}")
        return

    page = 1
    while True:
        chunk, current_page, total_pages = paginate_items(items, page=page, page_size=page_size)
        header = (
            f"{'ID':<8} | {'Item Name':<26} | {'Category':<13} | {'Price':>8} | "
            f"{'Cal':>5} | {'Type':<7} | {'Status'}"
        )
        print("\n" + "-" * len(header))
        print(f"{BOLD}{header}{RESET}")
        print("-" * len(header))

        for item in chunk:
            diet = "Veg" if item.is_veg else "Non-Veg"
            status_txt = f"{GREEN}Available{RESET}" if item.available else f"{RED}Out of Stock{RESET}"
            warn_flag = f" {YELLOW}[HIGH]{RESET}" if item.is_anomalous_price else ""
            print(
                f"{item.item_id:<8} | {item.name:<26} | {item.category:<13} | "
                f"Rs.{item.price:>5.2f} | {item.calories:>5} | {diet:<7} | {status_txt}{warn_flag}"
            )

        print("-" * len(header))
        print(f"Showing page {current_page} of {total_pages} ({len(items)} total record(s))")

        if total_pages <= 1:
            break

        nav = input("Navigation: [N]ext page, [P]revious page, or [Enter] to return: ").strip().lower()
        if nav == "n" and current_page < total_pages:
            page += 1
        elif nav == "p" and current_page > 1:
            page -= 1
        else:
            break


def handle_add_item(items: List[MenuItem], repo: MenuRepository) -> None:
    print(f"\n{BOLD}--- Add New Canteen Menu Item ---{RESET}")
    item_id = prompt_validated("Enter Item ID (e.g., MNU-36): ", validate_item_id)
    if any(existing.item_id == item_id for existing in items):
        print(f"{RED}[Error] Item ID '{item_id}' already exists.{RESET}")
        return

    name = prompt_validated("Enter Dish / Beverage Name: ", lambda v: sanitize_text(v, "Item Name"))
    print(f"Valid Categories: {', '.join(VALID_CATEGORIES)}")
    category = prompt_validated("Enter Category: ", validate_category)
    price = prompt_validated("Enter Price in INR (1 - 2000): ", validate_price)
    calories = prompt_validated("Enter Calories in kcal (0 - 3000): ", validate_calories)
    is_veg = prompt_validated("Is Vegetarian? (Y/N): ", validate_bool_flag)
    available = prompt_validated("Currently Available? (Y/N): ", validate_bool_flag)

    new_item = MenuItem(
        item_id=item_id,
        name=name,
        category=category,
        price=price,
        calories=calories,
        is_veg=is_veg,
        available=available,
    )
    items.append(new_item)
    repo.save_all(items)
    print(f"{GREEN}[Success] Added '{new_item.name}' (Rs.{new_item.price:.2f}) and persisted to disk.{RESET}")


def handle_update_or_delete(items: List[MenuItem], repo: MenuRepository) -> None:
    print(f"\n{BOLD}--- Update / Delete Menu Item ---{RESET}")
    target_id = prompt_validated("Enter Item ID to modify: ", validate_item_id)
    idx = next((i for i, item in enumerate(items) if item.item_id == target_id), None)
    if idx is None:
        print(f"{YELLOW}No item found with ID '{target_id}'.{RESET}")
        return

    item = items[idx]
    print(f"Selected: {item.name} | Category: {item.category} | Price: Rs.{item.price:.2f} | Available: {item.available}")
    action = input("Choose [U]pdate Price/Availability or [D]elete Item: ").strip().lower()

    if action == "d":
        removed = items.pop(idx)
        repo.save_all(items)
        print(f"{GREEN}[Success] Removed '{removed.name}' ({removed.item_id}).{RESET}")
        return

    if action == "u":
        new_price = prompt_validated(
            f"Enter new price (blank to keep Rs.{item.price:.2f}): ",
            validate_price,
            allow_blank_default=str(item.price),
        )
        new_avail = prompt_validated(
            f"Is available? Y/N (blank to keep {'Y' if item.available else 'N'}): ",
            validate_bool_flag,
            allow_blank_default="Y" if item.available else "N",
        )
        item.price = float(new_price)
        item.available = bool(new_avail)
        repo.save_all(items)
        print(f"{GREEN}[Success] Updated '{item.name}' -> Rs.{item.price:.2f}, Available={item.available}.{RESET}")
    else:
        print(f"{YELLOW}Action cancelled.{RESET}")


def handle_search_and_filter(items: List[MenuItem]) -> None:
    print(f"\n{BOLD}--- Search & Filter Canteen Menu ---{RESET}")
    keyword = input("Keyword (name/ID, or blank for all): ").strip()
    category = input(f"Category ({', '.join(VALID_CATEGORIES)}, or blank): ").strip()
    veg_raw = input("Vegetarian only? (Y/N, default N): ").strip()
    veg_only = veg_raw.lower() in ("y", "yes", "true", "1")
    max_price_raw = input("Max price in INR (or blank for no limit): ").strip()
    max_price = None
    if max_price_raw:
        try:
            max_price = validate_price(max_price_raw)
        except ValidationError as err:
            print(f"{RED}[Warning] Ignoring invalid max price: {err}{RESET}")

    matches = filter_items(items, keyword=keyword, category=category, veg_only=veg_only, max_price=max_price)
    render_items_table(matches, page_size=10)


def handle_combo_finder(items: List[MenuItem]) -> None:
    print(f"\n{BOLD}--- Affordable Meal Combination Finder ---{RESET}")
    budget = prompt_validated("Enter your maximum meal budget in INR (e.g., 100): ", validate_price)
    size_raw = input("Number of items in combo (2 or 3, default 2): ").strip() or "2"
    combo_size = 3 if size_raw == "3" else 2
    veg_only = input("Vegetarian combos only? (Y/N, default N): ").strip().lower() in ("y", "yes")

    combos = find_affordable_combos(
        items,
        max_budget=float(budget),
        combo_size=combo_size,
        veg_only=veg_only,
        distinct_categories=True,
        top_n=10,
    )
    if not combos:
        print(f"{YELLOW}No {combo_size}-item meal combinations fit within Rs.{float(budget):.2f}.{RESET}")
        return

    print(f"\n{GREEN}Top {len(combos)} Balanced Meal Combos within Rs.{float(budget):.2f}:{RESET}")
    print("-" * 82)
    print(f"{'#':<3} | {'Meal Combination':<42} | {'Total':>8} | {'Saved':>7} | {'Calories':>8}")
    print("-" * 82)
    for idx, combo in enumerate(combos, start=1):
        print(
            f"{idx:<3} | {combo.label:<42} | Rs.{combo.total_price:>5.2f} | "
            f"Rs.{combo.budget_remaining:>4.2f} | {combo.total_calories:>5} kcal"
        )
    print("-" * 82)


def handle_executive_summary(items: List[MenuItem]) -> None:
    summary = compute_menu_summary(items)
    print(f"\n{BOLD}--- Executive Menu & Pricing Summary ---{RESET}")
    if summary["total_items"] == 0:
        print("Menu catalog is empty.")
        return

    print(f"Total Menu Items   : {summary['total_items']} ({summary['available_items']} Available, {summary['unavailable_items']} Out of Stock)")
    print(f"Dietary Breakdown  : {summary['veg_count']} Veg | {summary['non_veg_count']} Non-Veg")
    print(f"Average Item Price : Rs.{summary['avg_price']:.2f} (Median: Rs.{summary['median_price']:.2f})")
    print(f"Cheapest Item      : {summary['min_item'].name} (Rs.{summary['min_item'].price:.2f})")
    print(f"Most Expensive     : {summary['max_item'].name} (Rs.{summary['max_item'].price:.2f})")
    print(f"Average Calories   : {summary['avg_calories']:.1f} kcal")

    if summary["warnings"]:
        print(f"\n{YELLOW}{BOLD}Threshold Warning Flags:{RESET}")
        for w in summary["warnings"]:
            print(f"  {YELLOW}! {w}{RESET}")

    print(f"\n{BOLD}Category-Wise Pricing Summary:{RESET}")
    print("-" * 64)
    print(f"{'Category':<16} | {'Count':>5} | {'Avg Price':>10} | {'Min':>9} | {'Max':>9}")
    print("-" * 64)
    for cat, stats in summary["category_breakdown"].items():
        print(
            f"{cat:<16} | {stats['count']:>5} | Rs.{stats['avg_price']:>7.2f} | "
            f"Rs.{stats['min_price']:>6.2f} | Rs.{stats['max_price']:>6.2f}"
        )
    print("-" * 64)


def handle_bulk_import(items: List[MenuItem], repo: MenuRepository) -> List[MenuItem]:
    print(f"\n{BOLD}--- Bulk CSV Dataset Import ---{RESET}")
    path = input("Enter CSV file path to import (e.g., data/bulk_import_sample.csv): ").strip()
    if not path:
        print(f"{YELLOW}No file path entered.{RESET}")
        return items
    try:
        updated_items, added, errors = repo.bulk_import_csv(path, items)
        repo.save_all(updated_items)
        print(f"{GREEN}[Success] Imported {added} new item(s).{RESET}")
        if errors:
            print(f"{YELLOW}Row-by-row validation log ({len(errors)} skipped):{RESET}")
            for err in errors[:10]:
                print(f"  - {err}")
        return updated_items
    except StorageError as err:
        print(f"{RED}[Storage Error] {err}{RESET}")
        return items


def run_cli(repo: MenuRepository) -> None:
    print_banner()
    try:
        items = repo.load_all()
        print(f"{GREEN}Loaded {len(items)} menu item(s) from persistent storage.{RESET}")
    except StorageError as err:
        print(f"{RED}[Critical Storage Error] {err}{RESET}")
        items = []

    while True:
        print(f"\n{BOLD}MAIN MENU{RESET}")
        print("1. View Full Menu Catalog (Paginated)")
        print("2. Add New Menu Item")
        print("3. Update / Delete Menu Item")
        print("4. Search & Filter Menu")
        print("5. Find Affordable Meal Combinations")
        print("6. Executive Summary & Threshold Warnings")
        print("7. Bulk Import CSV Dataset")
        print("8. Export Reports (Markdown, Audit Log, CSV & Chart)")
        print("9. Save & Exit")

        choice = input("\nSelect an option (1-9): ").strip()
        try:
            if choice == "1":
                render_items_table(items, page_size=10)
            elif choice == "2":
                handle_add_item(items, repo)
            elif choice == "3":
                handle_update_or_delete(items, repo)
            elif choice == "4":
                handle_search_and_filter(items)
            elif choice == "5":
                handle_combo_finder(items)
            elif choice == "6":
                handle_executive_summary(items)
            elif choice == "7":
                items = handle_bulk_import(items, repo)
            elif choice == "8":
                paths = export_reports(items, reports_dir="reports")
                print(f"{GREEN}[Success] Exported executive reports:{RESET}")
                for fmt, p in paths.items():
                    print(f"  - {fmt.upper()}: {p}")
            elif choice == "9":
                repo.save_all(items)
                print(f"{GREEN}All changes saved safely. Exiting Canteen Menu Analyzer.{RESET}")
                break
            else:
                print(f"{RED}[Error] Please choose a valid option between 1 and 9.{RESET}")
        except StorageError as err:
            print(f"{RED}[Storage Error] {err}{RESET}")
        except KeyboardInterrupt:
            print("\nInterrupted. Saving current state...")
            repo.save_all(items)
            break

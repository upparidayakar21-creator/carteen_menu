"""
Defensive Input Sanitization & Domain Validation Layer.
Prevents terminal crashes, invalid numeric entries, control-character injection, and domain breaches.
"""

import re
from typing import Tuple, Optional
from src.models import VALID_CATEGORIES

ITEM_ID_PATTERN = re.compile(r"^[A-Z0-9-]{2,15}$")
SAFE_TEXT_PATTERN = re.compile(r"^[A-Za-z0-9 &()'.,/-]{2,60}$")


class ValidationError(ValueError):
    """Raised when user or CSV input violates Canteen Menu Analyzer domain rules."""


def sanitize_text(raw: str, field_name: str = "Value", min_len: int = 2, max_len: int = 60) -> str:
    if not isinstance(raw, str):
        raise ValidationError(f"{field_name} must be a text string.")
    cleaned = re.sub(r"[\x00-\x1F\x7F]", "", raw).strip()
    if len(cleaned) < min_len or len(cleaned) > max_len:
        raise ValidationError(f"{field_name} must be between {min_len} and {max_len} characters.")
    if not SAFE_TEXT_PATTERN.match(cleaned):
        raise ValidationError(
            f"{field_name} contains unsupported characters. Use letters, numbers, spaces, or basic punctuation."
        )
    return cleaned


def validate_item_id(raw: str) -> str:
    cleaned = str(raw or "").strip().upper()
    if not ITEM_ID_PATTERN.match(cleaned):
        raise ValidationError("Item ID must be 2-15 uppercase alphanumeric characters (e.g., MNU-01).")
    return cleaned


def validate_category(raw: str) -> str:
    cleaned = str(raw or "").strip()
    lookup = {cat.lower(): cat for cat in VALID_CATEGORIES}
    if cleaned.lower() not in lookup:
        raise ValidationError(f"Category must be one of: {', '.join(VALID_CATEGORIES)}.")
    return lookup[cleaned.lower()]


def validate_price(raw: str | float | int, min_price: float = 1.0, max_price: float = 2000.0) -> float:
    try:
        val = float(str(raw).strip())
    except (ValueError, TypeError) as exc:
        raise ValidationError("Price must be a valid numeric value.") from exc
    if not (min_price <= val <= max_price):
        raise ValidationError(f"Price must be between Rs.{min_price:.2f} and Rs.{max_price:.2f}.")
    return round(val, 2)


def validate_calories(raw: str | int, min_cal: int = 0, max_cal: int = 3000) -> int:
    try:
        text = str(raw).strip()
        float_val = float(text)
        if not float_val.is_integer():
            raise ValidationError("Calories must be a whole integer.")
        val = int(float_val)
    except ValidationError:
        raise
    except (ValueError, TypeError) as exc:
        raise ValidationError("Calories must be a valid integer.") from exc
    if not (min_cal <= val <= max_cal):
        raise ValidationError(f"Calories must be between {min_cal} and {max_cal} kcal.")
    return val


def validate_bool_flag(raw: str | bool) -> bool:
    if isinstance(raw, bool):
        return raw
    cleaned = str(raw or "").strip().lower()
    if cleaned in ("y", "yes", "true", "1", "veg", "available"):
        return True
    if cleaned in ("n", "no", "false", "0", "non-veg", "unavailable"):
        return False
    raise ValidationError("Enter Y/Yes/True or N/No/False.")


def prompt_validated(prompt_text: str, parser_fn, allow_blank_default: Optional[str] = None):
    """Loops cleanly in CLI until valid sanitized input is provided."""
    while True:
        raw = input(prompt_text)
        if allow_blank_default is not None and raw.strip() == "":
            return allow_blank_default
        try:
            return parser_fn(raw)
        except ValidationError as err:
            print(f"\033[91m[Validation Error] {err}\033[0m")

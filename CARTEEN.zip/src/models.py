"""
Domain Models & Schema Definitions for Canteen Menu Analyzer.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Tuple

VALID_CATEGORIES: Tuple[str, ...] = (
    "Breakfast",
    "Main Course",
    "Snacks",
    "Beverages",
    "Desserts",
    "Healthy Bowl",
)

BUDGET_THRESHOLD_INR: float = 100.0
PREMIUM_PRICE_WARNING_INR: float = 200.0
LOW_CALORIE_THRESHOLD: int = 450


@dataclass(frozen=False)
class MenuItem:
    """Represents a single canteen food or beverage item with nutritional and pricing metadata."""

    item_id: str
    name: str
    category: str
    price: float
    calories: int
    is_veg: bool = True
    available: bool = True
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @property
    def price_tier(self) -> str:
        if self.price <= 45.0:
            return "Budget"
        if self.price <= 110.0:
            return "Standard"
        return "Premium"

    @property
    def is_anomalous_price(self) -> bool:
        return self.price > PREMIUM_PRICE_WARNING_INR or self.price <= 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "name": self.name,
            "category": self.category,
            "price": round(float(self.price), 2),
            "calories": int(self.calories),
            "is_veg": bool(self.is_veg),
            "available": bool(self.available),
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "MenuItem":
        return cls(
            item_id=str(raw["item_id"]).strip().upper(),
            name=str(raw["name"]).strip(),
            category=str(raw["category"]).strip(),
            price=round(float(raw["price"]), 2),
            calories=int(raw["calories"]),
            is_veg=str(raw.get("is_veg", True)).strip().lower() in ("true", "1", "yes", "y"),
            available=str(raw.get("available", True)).strip().lower() in ("true", "1", "yes", "y"),
            updated_at=str(raw.get("updated_at") or datetime.now().isoformat(timespec="seconds")).strip(),
        )


@dataclass
class MealCombo:
    """Represents an affordable multi-item meal combination within a target budget."""

    items: Tuple[MenuItem, ...]
    total_price: float
    total_calories: int
    budget_remaining: float
    value_score: float

    @property
    def label(self) -> str:
        return " + ".join(item.name for item in self.items)

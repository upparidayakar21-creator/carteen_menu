# Canteen Menu Analyzer (v2.0 — Modular 3-Layer Architecture)

A terminal-driven Python application engineered for **Project #63: Canteen Menu Analyzer (GreenFuture Hack)** to manage canteen menus, summarize category pricing, detect price/stock anomalies, and compute affordable multi-item meal combinations within student budgets.

## Architecture & Scalability Highlights
- **Layered Modularity (`src/`):**
  - `src/models.py` — Domain dataclasses (`MenuItem`, `MealCombo`) with computed pricing tiers and anomaly flags.
  - `src/validators.py` — Regex-enforced input sanitization, numeric boundary checks, and centralized retry loops.
  - `src/storage.py` — Repository pattern with **atomic temp-file persistence** (`os.replace`) across both JSON and CSV, graceful recovery on corrupted files, OS-level `PermissionError` handling, and row-by-row validated bulk CSV imports.
  - `src/analytics.py` — Pure business-logic engine implementing `itertools.combinations` budget combo optimization, category aggregation, pagination slicing, and multi-format report generation.
  - `src/cli.py` — ANSI-formatted terminal UI with fixed-width paginated tables (`10 items/page`).
- **Automated Test Suite (`tests/test_canteen_analyzer.py`):** 7 comprehensive unit & integration tests verifying validation, persistence recovery, OS file-lock handling, combo optimization, pagination, and report exports.

## Quick Start

### 1. Run Automated Unit Tests
```bash
python -m unittest discover -s tests -v
```

### 2. Launch Canteen Menu Analyzer
```bash
python main.py
```

*(Optional)* Install `matplotlib` (`pip install -r requirements.txt`) to also generate PNG bar charts during report export (`Option 8`).

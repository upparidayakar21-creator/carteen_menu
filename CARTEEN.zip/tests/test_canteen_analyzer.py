"""
Comprehensive Automated Test Suite for Canteen Menu Analyzer.
Covers:
  - Defensive input validation & sanitization
  - Atomic CSV/JSON repository persistence & PermissionError / corruption handling
  - Bulk CSV dataset import with row-by-row error logging
  - Price summary analytics & threshold warnings
  - Affordable meal combination algorithm (itertools.combinations)
  - Pagination slicing & multi-format report exports
Run with: python -m unittest discover -s tests -v
"""

import os
import tempfile
import unittest
from unittest.mock import patch

from src.models import MenuItem
from src.validators import (
    ValidationError,
    sanitize_text,
    validate_item_id,
    validate_category,
    validate_price,
    validate_calories,
    validate_bool_flag,
)
from src.storage import MenuRepository, StorageError
from src.analytics import (
    paginate_items,
    filter_items,
    compute_menu_summary,
    find_affordable_combos,
    export_reports,
)


class TestCanteenMenuAnalyzer(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.csv_path = os.path.join(self.tmp_dir.name, "menu.csv")
        self.json_path = os.path.join(self.tmp_dir.name, "menu.json")
        self.repo = MenuRepository(csv_path=self.csv_path, json_path=self.json_path)

        self.sample_items = [
            MenuItem("MNU-01", "Masala Dosa", "Breakfast", 45.0, 320, True, True),
            MenuItem("MNU-02", "Ginger Chai", "Beverages", 15.0, 85, True, True),
            MenuItem("MNU-03", "Veg Pulao", "Main Course", 65.0, 480, True, True),
            MenuItem("MNU-04", "Chicken Roll", "Snacks", 70.0, 440, False, True),
            MenuItem("MNU-05", "Mango Smoothie", "Beverages", 50.0, 240, True, False),
            MenuItem("MNU-06", "Dry-Fruit Falooda", "Desserts", 220.0, 520, True, True),
        ]

    def tearDown(self):
        self.tmp_dir.cleanup()

    def test_input_validators_accept_valid_and_reject_invalid(self):
        self.assertEqual(validate_item_id("mnu-09"), "MNU-09")
        self.assertEqual(sanitize_text("  Paneer   Tikka  "), "Paneer   Tikka")
        self.assertEqual(validate_category("breakfast"), "Breakfast")
        self.assertEqual(validate_price("49.999"), 50.0)
        self.assertEqual(validate_calories("350"), 350)
        self.assertTrue(validate_bool_flag("yes"))
        self.assertFalse(validate_bool_flag("0"))

        with self.assertRaises(ValidationError):
            validate_item_id("bad id!")
        with self.assertRaises(ValidationError):
            validate_category("UnknownCategory")
        with self.assertRaises(ValidationError):
            validate_price("-5")
        with self.assertRaises(ValidationError):
            validate_calories("12.5")

    def test_atomic_persistence_roundtrip_and_corrupt_json_recovery(self):
        self.repo.save_all(self.sample_items)
        loaded = self.repo.load_all()
        self.assertEqual(len(loaded), 6)
        self.assertEqual(loaded[0].name, "Masala Dosa")

        # Simulate corrupted JSON file; repository should recover cleanly from CSV backup
        with open(self.json_path, "w", encoding="utf-8") as fh:
            fh.write("{corrupted-json")
        recovered = self.repo.load_all()
        self.assertEqual(len(recovered), 6)

    def test_os_permission_error_raises_storage_error(self):
        with patch("os.replace", side_effect=PermissionError("File locked by another process")):
            with self.assertRaises(StorageError):
                self.repo.save_all(self.sample_items)

    def test_bulk_csv_import_logs_bad_rows_and_duplicates(self):
        import_csv = os.path.join(self.tmp_dir.name, "import.csv")
        with open(import_csv, "w", encoding="utf-8") as fh:
            fh.write("item_id,name,category,price,calories,is_veg,available\n")
            fh.write("MNU-10,Idli Plate,Breakfast,30,210,True,True\n")
            fh.write("MNU-01,Duplicate Dosa,Breakfast,45,320,True,True\n")
            fh.write("BAD,Broken Price,Snacks,-10,100,True,True\n")

        updated, added, errors = self.repo.bulk_import_csv(import_csv, self.sample_items)
        self.assertEqual(added, 1)
        self.assertEqual(len(updated), 7)
        self.assertEqual(len(errors), 2)

    def test_affordable_meal_combinations_respects_budget_and_diet(self):
        combos = find_affordable_combos(self.sample_items, max_budget=85.0, combo_size=2, veg_only=True)
        self.assertTrue(len(combos) >= 2)
        for combo in combos:
            self.assertLessEqual(combo.total_price, 85.0)
            self.assertTrue(all(item.is_veg and item.available for item in combo.items))

    def test_executive_summary_and_threshold_warnings(self):
        summary = compute_menu_summary(self.sample_items)
        self.assertEqual(summary["total_items"], 6)
        self.assertEqual(summary["unavailable_items"], 1)
        self.assertEqual(summary["min_item"].item_id, "MNU-02")
        self.assertEqual(summary["max_item"].item_id, "MNU-06")
        self.assertTrue(any("High-price threshold alert" in w for w in summary["warnings"]))

    def test_pagination_and_multi_format_report_exports(self):
        page1, p_num, total_pages = paginate_items(self.sample_items, page=1, page_size=4)
        self.assertEqual(len(page1), 4)
        self.assertEqual((p_num, total_pages), (1, 2))

        filtered = filter_items(self.sample_items, veg_only=True, available_only=True, max_price=70.0)
        self.assertEqual(len(filtered), 3)

        reports_dir = os.path.join(self.tmp_dir.name, "reports")
        exported = export_reports(self.sample_items, reports_dir=reports_dir)
        self.assertTrue(os.path.exists(exported["markdown"]))
        self.assertTrue(os.path.exists(exported["audit_log"]))
        self.assertTrue(os.path.exists(exported["csv"]))


if __name__ == "__main__":
    unittest.main()

"""
Entry Point for Canteen Menu Analyzer (GreenFuture Hack — Project #63).
"""

from src.storage import MenuRepository
from src.cli import run_cli


def main() -> None:
    repo = MenuRepository(
        csv_path="data/menu_items.csv",
        json_path="data/menu_items.json",
    )
    run_cli(repo)


if __name__ == "__main__":
    main()
